CREATE TABLE Patient(
patient_id VARCHAR2(20),
Patient_name VARCHAR2(20),
age number(2),
description varchar2(20),
Phone_Number VARCHAR2(20),
appointmentDate DATE
);

CREATE SEQUENCE donorId_sequence
START WITH 1000;