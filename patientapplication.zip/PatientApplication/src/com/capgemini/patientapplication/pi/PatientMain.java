package com.capgemini.patientapplication.pi;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.patientapplication.bean.PatientBean;
import com.capgemini.patientapplication.exception.PatientException;
import com.capgemini.patientapplication.service.IPatientService;
import com.capgemini.patientapplication.service.PatientServiceImpl;

public class PatientMain {
	static Scanner sc = new Scanner(System.in);
	static IPatientService donorService = null;
	static PatientServiceImpl donorServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean donorBean = null;

		String donorId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Take Care Clinic ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add patient information ");
			System.out.println("2.Search patient by id");
			//System.out.println("3.Retrive All");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (donorBean == null) {
						donorBean = populateDonorBean();
						// System.out.println(donorBean);
					}

					try {
						donorService = new PatientServiceImpl();
						donorId = donorService.addDonorDetails(donorBean);

						System.out.println("Donator details  has been successfully registered ");
						System.out.println("Donator  ID Is: " + donorId);

					} catch (PatientException donorException) {
						logger.error("exception occured", donorException);
						System.err.println("ERROR : "+ donorException.getMessage());
					} finally {
						donorId = null;
						donorService = null;
						donorBean = null;
					}

					break;

				case 2:

					donorServiceImpl = new PatientServiceImpl();

					System.out.println("Enter numeric donor id:");
					donorId = sc.next();

					while (true) {
						if (donorServiceImpl.validateDonorId(donorId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric donor id only, try again");
							donorId = sc.next();
						}
					}

					donorBean = getDonorDetails(donorId);

					if (donorBean != null) {
						System.out.println("Name             :"
								+ donorBean.getPatient_name());
						/*System.out.println("Address          :"
								+ donorBean.getAddress());*/
						System.out.println("Phone Number     :"
								+ donorBean.getPhoneNumber());
						System.out.println("Donor Date       :"
								+ donorBean.getappointmentDate());
						/*System.out.println("Donation Amount  :"
								+ donorBean.getDonationAmount());*/
					} else {
						System.err
								.println("There are no donation details associated with donor id "
										+ donorId);
					}

					break;

				/*case 3:

					donorService = new DonorServiceImpl();
					try {
						List<DonorBean> donorList = new ArrayList<DonorBean>();
						donorList = donorService.retriveAll();

						if (donorList != null) {
							Iterator<DonorBean> i = donorList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

					}

					catch (DonorException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;*/

				case 3:

					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given donorId in
	 * parameter
	 */
	private static PatientBean getDonorDetails(String donorId) {
		PatientBean donorBean = null;
		donorService = new PatientServiceImpl();

		try {
			donorBean = donorService.viewDonorDetails(donorId);
		} catch (PatientException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		donorService = null;
		return donorBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static PatientBean populateDonorBean() {

		// Reading and setting the values for the donorBean
		
		PatientBean donorBean = new PatientBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter donor name: ");
		donorBean.setPatient_name(sc.next());
		
		System.out.println("Enter patient age: ");
		donorBean.setAge(sc.nextInt());
		System.out.println("Enter the description: ");
		donorBean.setDescription(sc.next());
		System.out.println("Enter donor contact: ");
		donorBean.setPhoneNumber(sc.next());

		/*System.out.println("Enter donor address: ");
		donorBean.setAddress(sc.next());
*/
		//System.out.println("Enter donation amount: ");

		/*try {
			donorBean.setDonationAmount(sc.nextFloat());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err.println("Please enter a numeric value for donation amount, try again");
			}*/

		donorServiceImpl = new PatientServiceImpl();

		try {
			donorServiceImpl.validateDonor(donorBean);
			return donorBean;
		} catch (PatientException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}


