package com.capgemini.patientapplication.bean;

import java.util.Date;


public class PatientBean 
{
	private int patient_id;
	private String patient_name;
	private int age;
	private String phoneNumber;
	private String description;
	//private double donationAmount;
	private Date appointmentDate;
	
	/*public String getDonorId() {
		return donorId;
	}
	public void setDonorId(String donorId) {
		this.donorId = donorId;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}*/
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPatient_name() {
		return patient_name;
	}
	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getDonor_id() {
		return patient_id;
	}
	public void setDonor_id(int donor_id) {
		this.patient_id = donor_id;
	}
	/*public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDonationAmount() {
		return donationAmount;
	}
	public void setDonationAmount(double donationAmount) {
		this.donationAmount = donationAmount;
	}*/
	public Date getappointmentDate() {
		return appointmentDate;
	}
	public void setappointmentDate(Date appointmentDate) {
		this.appointmentDate =appointmentDate;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append("Printing patient Details \n");
		sb.append("patient_id:"+patient_id+"\n");
		sb.append("patient Name: " +patient_name +"\n");
		sb.append("Age :"+age+"\n");
		//sb.append("Donor Address: "+ address +"\n");
		sb.append("Phone Number: "+ phoneNumber +"\n");
		sb.append("Description:"+description+"\n");
		//sb.append("Donation Amount: "+ donationAmount +"\n");
		sb.append("Donation Date: "+ appointmentDate);
		return sb.toString();
	}
	
	

	
}
