package com.capgemini.patientapplication.service;

import java.util.List;

import com.capgemini.patientapplication.bean.PatientBean;
import com.capgemini.patientapplication.exception.PatientException;

public interface IPatientService 
{
	public String addDonorDetails(PatientBean donor) throws PatientException;
	public PatientBean viewDonorDetails(String donorId) throws PatientException;
	//public List<DonorBean> retriveAll()throws DonorException;
}
