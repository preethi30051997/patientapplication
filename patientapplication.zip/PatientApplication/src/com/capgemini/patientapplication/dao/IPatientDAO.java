package com.capgemini.patientapplication.dao;

import java.util.List;

import com.capgemini.patientapplication.bean.PatientBean;
import com.capgemini.patientapplication.exception.PatientException;

public interface IPatientDAO 
{
	public String addDonorDetails(PatientBean donor) throws PatientException;
	public PatientBean viewDonorDetails(String donorId) throws PatientException;
	//public List<DonorBean> retriveAllDetails()throws DonorException;
}
