package com.capgemini.donorapplication.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.patientapplication.bean.PatientBean;
import com.capgemini.patientapplication.dao.PatientDaoImpl;
import com.capgemini.patientapplication.exception.PatientException;
import com.capgemini.patientapplication.service.IPatientService;
import com.capgemini.patientapplication.service.PatientServiceImpl;

public class PatientDaoTest {

	static PatientDaoImpl dao;
	static PatientBean donor;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new PatientDaoImpl();
		donor = new PatientBean();
	}

	@Test
	public void testAddDonarDetails() throws PatientException {

		assertNotNull(dao.addDonorDetails(donor));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws PatientException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addDonorDetails(donor));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws PatientException {

		donor.setPatient_name("Preethi");
		donor.setPhoneNumber("9876543212");
		donor.setAge(21);
		donor.setDescription("fever");
		//donor.setAddress("whitefieldVydehi");
		//donor.setDonationAmount(12000);
		assertEquals(1001, dao.addDonorDetails(donor));
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	/*@Test
	public void testViewAll() throws DonorException {
		assertNotNull(dao.retriveAllDetails());
	}*/

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws PatientException {
		assertNotNull(dao.viewDonorDetails("1010"));
	}

	@Ignore
	@Test
	public void testById1() throws PatientException {
		assertEquals("TestName", dao.viewDonorDetails("1010").getPatient_name());
	}

}
